library(testthat)
library(ggperiodic)

test_check("ggperiodic")
